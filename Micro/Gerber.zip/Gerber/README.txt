Samuel Deghuee
Sdeghuee@gmail.com
(408)693-8003
1/6/2016
STM32f407layout
X:61.43 Y: 90.98 (mm)
Area:5,588.9 mm^2